# NetRF 무선 구간 속도 측정 서버

NetRF 앱 속도 탭의 **① 무선 구간**을 재는 상대. 와이파이 단말 → AP → (유선) → 이 서버까지의 속도를 잰다(인터넷 회선과 상관없이).
**없어도 앱은 돈다** — 서버가 없으면 인터넷(Cloudflare)만 잰다.

- 파일 하나(`speed-server.py`, 파이썬 3 표준 라이브러리만). 받은 데이터는 저장하지 않고 버린다.
- 규약은 Cloudflare 측정 서버와 같다: `GET /__down?bytes=N`(0 으로 채운 N 바이트, 최대 100 MB) · `POST /__up`(받고 버림).
- 서버는 **유선**으로 망에 붙어 있어야 한다(와이파이면 무선을 두 번 타서 결과가 섞인다).

## 노트북·PC 에서(윈도우 — 측정 기사용, 권장)

`netrf-server.exe` 하나(설치 없음, 약 5 MB). 받기 페이지 https://jhgen77-cloud.github.io/netrf/ (집 안에선 http://192.168.123.250:8099/netrf/) 또는 `server/go/build.sh` 로 만든 `server/dist/`.

1. 노트북을 사업장 **유선**(스위치·공유기 포트)에 꽂는다 — 와이파이로만 붙어 있으면 창에 경고가 뜬다.
2. `netrf-server.exe` 를 **마우스 오른쪽 → 관리자 권한으로 실행**(권장). 방화벽을 저절로 열고(공용·개인 모두) 창을 닫으면 지운다.
   그냥 더블클릭해도 되지만, 사업장 유선은 윈도우가 보통 **공용 네트워크**로 잡아서 "액세스 허용"을 눌러도 패드가 못 붙는 일이 잦다
   (창에 `· 공용 네트워크` 와 경고가 뜬다). "Windows의 PC 보호" 창이 뜨면 추가 정보 → 실행.
3. 창에 `유선  http://<IP>:8098` 이 보이면 준비 끝. 패드 NetRF → 속도 탭이 **저절로 찾는다**(UDP 8097 방송).
   패드가 닿으면 창에 `패드가 찾음`(자동 찾기)·`단말 접속`(측정) 줄이 뜬다.
4. 끝나면 창을 닫는다. 잊어도 **30 분 동안 측정이 없으면 저절로 꺼진다**(`netrf-server.exe --idle 60` = 60 분, `--idle 0` = 안 꺼짐).
   다른 포트: `--port 80`. 받은 데이터는 저장하지 않는다.

### 패드가 서버를 못 찾을 때

1. 노트북 브라우저 `http://localhost:8098/__info` → JSON 이 나오면 서버는 정상.
2. 패드 브라우저 `http://<창의 IP>:8098/__info`
   - 열리면 → 자동 찾기(방송)만 막힌 망. 앱 ⚙ → 무선 구간 서버에 그 주소.
   - 안 열리고 창에 아무 줄도 안 뜨면 → 방화벽(관리자 권한으로 다시 실행) 또는 패드 SSID 와 노트북 유선이 서로 막힌 망(게스트 SSID·다른 VLAN).
3. ACL 로 무선 → 유선이 막힌 곳(회사망에 흔함):
   - **WLC ACL**(무선 컨트롤러가 단말 트래픽에 거는 것) — 노트북을 무선과 같은 VLAN 에 꽂아도 WLC 를 지나므로 걸린다.
     WLC ACL 은 보통 상태를 기억하지 않으므로 두 줄을 deny 보다 위에: `무선 대역 → 노트북IP/32 TCP 목적지 8098 허용`, `노트북IP/32 출발지 8098 → 무선 대역 TCP 허용`.
   - 고칠 수 없으면 ACL 이 이미 열어 둔 포트로 띄운다(예: 사내 웹이 열려 있으면 `netrf-server.exe --port 80`) → 앱 ⚙ 에 `http://<IP>:80`.
   - 스위치·방화벽 ACL 이면 노트북을 무선과 같은 VLAN 포트에 꽂는 쪽이 쉽다.
   - WLC 망에서는 단말의 방송(UDP 8097)을 WLC 가 대개 버리므로 자동 찾기가 안 된다 — 앱 ⚙ 에 주소를 넣는다.
4. 관리자 권한이 없는 회사 PC 는 그룹 정책으로 막혀 있을 수 있다 — 관리자에게 아래를 부탁한다:
   `netsh advfirewall firewall add rule name=NetRF-server dir=in action=allow program="<exe 경로>" enable=yes profile=any`

자동 찾기는 같은 망(같은 브로드캐스트 대역)에서만 된다 — 서버가 다른 VLAN(예: Net-ITAM 서버 대역)이면 앱 ⚙ → 무선 구간 서버에 주소를 넣는다.
Go 로 만들었다(`server/go/`, 표준 라이브러리만). 다시 만들기: `server/go/build.sh`(도커 golang 이미지로 윈도우·리눅스·맥용).

## 도커로(서버 — CentOS 등 도커가 있는 리눅스, 예: Net-ITAM 서버)

이 폴더(`server/`)를 서버에 복사한 뒤:

```bash
cd server
docker compose up -d          # 옛 도커: docker-compose up -d
docker logs netrf-speed       # "NetRF speed server — port 8098" 이 보이면 됨. 측정마다 한 줄씩 찍힌다
```

재부팅하면 저절로 다시 뜬다(`restart: unless-stopped`). 끄기: `docker compose down`.

### 서버가 인터넷에 못 나가면(이미지 받기 불가)

인터넷 되는 PC 에서 이미지를 만들어 파일로 옮긴다:

```bash
docker build -t netrf-speed:1 server/
docker save netrf-speed:1 | gzip > netrf-speed.tar.gz
# 서버로 복사한 뒤
gunzip -c netrf-speed.tar.gz | docker load
docker run -d --name netrf-speed --restart unless-stopped -p 8098:8098 --cpus 1 -m 128m netrf-speed:1
```

## 방화벽(CentOS firewalld)

```bash
firewall-cmd --permanent --add-port=8098/tcp && firewall-cmd --reload
```

도커가 포트를 열 때 firewalld 를 거치지 않는 경우가 많다(도커 자체 iptables 규칙). 무선 대역에서만 받게 하려면 compose 의
`ports` 를 `"<서버IP>:8098:8098"` 로 묶고, 망 장비(ACL)에서 무선 SSID 대역 → 서버 8098 만 허용하는 쪽이 확실하다.

## 도커 없이

```bash
python3 speed-server.py            # 포트 8098, --port 로 바꿈
```

시작하면 창에 이 PC 주소와 링크 속도가 뜬다(1 Gbps 미만이거나 와이파이면 경고).
측정마다 `단말IP  down  50.0 MB  ~412 Mbps` 한 줄 — 서버 쪽 참고값이고 정답은 앱 값.

| 옵션 | 기본 | 뜻 |
|---|---|---|
| `--allow 10.20.0.0/16` | 사설망 전체 | 받을 단말 대역(쉼표로 여러 개, `any` = 모두). 상시 운영인데 ACL 을 못 바꿀 때 |
| `--idle 30` | 30 분 | 요청이 이만큼 없으면 저절로 끝. `0` = 안 끝냄(도커는 0) |
| `--max-conn 16` | 16 | 동시 연결 수. 넘으면 바로 끊는다. 연결마다 30 초 말이 없으면 끊는다 |
| `--quiet` | — | 측정마다 찍는 줄을 끈다 |

측정마다 창에 한 줄씩 찍힌다(서버 쪽 참고값, 정답은 앱 값). 다운·업 10초가 끝날 때 앱이 하던 요청을 끊으므로 **끝에 `(끊김)` 줄이 연결 수(4)만큼 나오는 건 정상**이다.
느린 망(연결당 ~3 Mbps 아래)은 업로드 4 MB 한 덩이를 10초 안에 다 못 보내 업로드 줄이 모두 `(끊김)` 이 된다(11-02 회사 "3.6/4 MB (cut)" 이 이것).

파이썬 3.6(CentOS 7 기본)부터 된다. 윈도우 노트북도 파이썬이 있으면 `python speed-server.py` 로 같다.
윈도우에서 파이썬 판은 **방화벽을 스스로 열지 않는다**(exe 와 다름). 방화벽이 켜진 PC 면 관리자 명령 프롬프트에서 포트만 연다(끝나면 `delete rule name=NetRF-8098`):
`netsh advfirewall firewall add rule name=NetRF-8098 dir=in action=allow protocol=TCP localport=8098 profile=any`

**한 PC 는 되고 다른 PC 는 패드가 못 붙을 때는 먼저 WLC ACL**(2026-11-05 회사: 노트북은 되고 데스크톱은 안 됨 → WLC ACL 이었다, 방화벽 아님).
가르는 시험: 된 PC 브라우저 → `http://<안 된 PC IP>:8098/__down?bytes=1000`(유선끼리라 WLC 를 안 탄다). 열리면 PC 는 정상이고 무선 → 그 IP 가 ACL 에 없는 것.

## 앱에서

⚙ → **무선 구간 서버** 에 `http://<서버 IP>:8098` (사설 IP 만 받는다). 확인: 단말 브라우저로 `http://<서버 IP>:8098/__down?bytes=0` → 빈 응답(200).

## 주의

- 패드가 붙은 SSID 에서 서버 IP:8098 에 닿아야 한다 — 인터넷만 허용하는 모바일·게스트 SSID 에서는 안 닿을 수 있다.
- 측정하는 10~20 초 동안 서버 NIC 에 수백 Mbps 가 오간다(compose 에서 CPU 1개·메모리 128 MB 로 묶음).
